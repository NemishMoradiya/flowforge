"use client";

import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      theme="dark"
      position="top-right"
      richColors
      toastOptions={{
        className: "bg-background border text-foreground",
      }}
    />
  );
}
